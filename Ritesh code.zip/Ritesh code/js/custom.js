// JavaScript Document
$(document).ready(function () {
	
	$(function () {
		$('select').selectpicker();
	});

	$('#menu-toggle').click(function () {
		$(this).toggleClass('open');
		$('#sidebarMenu').toggleClass('show');
	})

	var url = window.location.href;
	  	$('.nav li a[href="'+url+'"]').addClass('active');
	  	$(".search-btn").click(function () {
		  	$(".search-box").toggle();
	 	 });
	  	$('[data-toggle="tooltip"]').tooltip();
	  	$(document).click(function (e) {
		  	if (!$(e.target).hasClass("search-btn") && $(e.target).parents(".search-box").length === 0) 
		  	{
			  	$(".search-box").hide();
		  	}
	});

	var dropdown = document.getElementsByClassName("dropdown-btn");
	var i;
	for (i = 0; i < dropdown.length; i++) {
		dropdown[i].addEventListener("click", function() {
			this.classList.toggle("active");
			var dropdownContent = this.nextElementSibling;
			if (dropdownContent.style.display === "none") {
				dropdownContent.style.display = "block";
			} else {
				dropdownContent.style.display = "none";
			}
		});
	}

	var divHeight = $(this).find('.side-img').height() - 100; 
	$('.row').each(function(){
		$(this).find('.side-content').css('height', divHeight+'px');
	});
	
	$(window).load(function () {
		$(".bodyloader").css({'opacity':'0', 'z-index':'-2'}).animate(100);
		$('html, body').animate({ scrollTop: 0 });
		
		$('.banner-img').height($('.banner').height());
		$(".brandtxt").css({'opacity':'1'});
		$(".reveal").css({'width':'0'});
		$(".reveal-banner").css({'width':'0'});
		$(".top-strip").css({'opacity':'1'});
		
		//$(".reveale").css({'opacity':'0', 'z-index':'-100'});
		$('.row').each(function(){
			$(this).find('.side-content').css('height', divHeight+'px');
		});
		$('.detail-box').height($('.pro-img').height() - 160 ); 
	});

	$(window).resize(function () {
		$('.banner-img').height($('.banner').height());
		$(".brandtxt").css({'opacity':'1'});
		$(".reveal").css({'width':'0'});
		$(".reveal-banner").css({'width':'0'});
		$(".top-strip").css({'opacity':'1'});

		$('.row').each(function(){
			$(this).find('.side-content').css('height', divHeight+'px');
		});
		$('.detail-box').height($('.pro-img').height() - 160 );
	});
	
	//---------Menu fix on scroll
	$(window).scroll(function() {
		if ($(document).scrollTop() > 50) {
			$('.header').addClass('shrink');
			//$('.banner').addClass('shrink');
		}
		else {
			$('.header').removeClass('shrink');
			//$('.banner').removeClass('shrink');
		}
	});
	//---------Menu fix on scroll

//---------smooth page scroll
$(function(){
	var $window = $(window);	//Window object
	var scrollTime = 0.5;		//Scroll time
	var scrollDistance = 150;	//Distance. Use smaller value for shorter scroll and greater value for longer scroll
	$window.on("mousewheel DOMMouseScroll", function(event){
		event.preventDefault();	
		var delta = event.originalEvent.wheelDelta/120 || -event.originalEvent.detail/3;
		var scrollTop = $window.scrollTop();
		var finalScroll = scrollTop - parseInt(delta*scrollDistance);
			
		TweenMax.to($window, scrollTime, {
			scrollTo : { y: finalScroll, autoKill:true },
				ease: Power1.easeOut,	//For more easing functions see https://api.greensock.com/js/com/greensock/easing/package-detail.html
				autoKill: true,
				overwrite: 10							
			});
	});
});
//---------smooth page scroll

//---------scroll to top button
$(window).scroll(function () {
	if ($(this).scrollTop() > 2200) {
		$('.showhead').fadeIn().animate(1000);
	} 
	else {
		$('.showhead').fadeOut().animate(1000);
	}
});
$('.scrollToTop').click(function () {
	$('html, body').animate({ scrollTop: 0 }, 2100);
	return false;
});
//---------scroll to top button
	
	
$(".mid-nav li a[href^='#']").on('click', function(e) {
     var target;
     target = this.hash;
	e.preventDefault();

     // The grabs the height of my header
     var navOffset;
     navOffset = $('.white-strip').height() + 85;

     // Animate The Scroll
     $('html, body').animate({
         scrollTop: $(this.hash).offset().top - navOffset
     }, 800, function(){

     // Adds hash to end of URL
     return window.history.pushState(null, null, target);

     });

});

		
	
		
	$('.input-number').focusin(function(){
			$(this).data('oldValue', $(this).val());
	});

	$('.input-number').change(function() {
		minValue =  parseInt($(this).attr('min'));
		maxValue =  parseInt($(this).attr('max'));
		valueCurrent = parseInt($(this).val());
		name = $(this).attr('name');
		if(valueCurrent >= minValue) {
				$(".btn-number[data-type='minus'][data-field='"+name+"']").removeAttr('disabled')
		} else {
				alert('Sorry, the minimum value was reached');
				$(this).val($(this).data('oldValue'));
		}
		if(valueCurrent <= maxValue) {
				$(".btn-number[data-type='plus'][data-field='"+name+"']").removeAttr('disabled')
		} else {
				alert('Sorry, the maximum value was reached');
				$(this).val($(this).data('oldValue'));
		}
	});
	//plugin bootstrap minus and plus---------------------


	$('.collapse').on('shown.bs.collapse', function(){
		$(this).parent().find(".fa-plus").removeClass("fa-plus").addClass("fa-minus");
		}).on('hidden.bs.collapse', function(){
		$(this).parent().find(".fa-minus").removeClass("fa-minus").addClass("fa-plus");
	});

	
});	



function isMobile(width) {
	// "use strict";
	// if(width == undefined){
	// 	width = 300;
	// }
	
	// if(window.innerWidth <= width) {
	// 	return true;
	// }
	// else {
	// 	return false;
	// }
}
